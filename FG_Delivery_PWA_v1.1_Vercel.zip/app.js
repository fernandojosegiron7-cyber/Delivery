const els={
  installBtn:document.getElementById('installBtn'),
  startBtn:document.getElementById('startBtn'),
  stopBtn:document.getElementById('stopBtn'),
  statusDot:document.getElementById('statusDot'),
  statusText:document.getElementById('statusText'),
  orderTitle:document.getElementById('orderTitle'),
  orderMeta:document.getElementById('orderMeta'),
  lat:document.getElementById('lat'),
  lng:document.getElementById('lng'),
  accuracy:document.getElementById('accuracy'),
  lastUpdate:document.getElementById('lastUpdate'),
  ajaxUrl:document.getElementById('ajaxUrl'),
  driverToken:document.getElementById('driverToken'),
  saveConfig:document.getElementById('saveConfig'),
  testConfig:document.getElementById('testConfig')
};

let watchId=null;
let wakeLock=null;
let installPrompt=null;
let lastSent=0;

const qs=new URLSearchParams(location.search);
const urlToken=qs.get('token')||qs.get('driver_token')||'';
const urlAjax=qs.get('ajax')||'';

const saved=JSON.parse(localStorage.getItem('fgDeliveryConfig')||'{}');
els.ajaxUrl.value=urlAjax||saved.ajaxUrl||'';
els.driverToken.value=urlToken||saved.driverToken||'';

function toast(msg){
  const t=document.createElement('div');
  t.className='toast'; t.textContent=msg; document.body.appendChild(t);
  setTimeout(()=>t.remove(),2600);
}
function setLive(live,msg){
  els.statusDot.classList.toggle('live',live);
  els.statusText.textContent=msg;
}
function saveConfig(){
  const cfg={ajaxUrl:els.ajaxUrl.value.trim(),driverToken:els.driverToken.value.trim()};
  localStorage.setItem('fgDeliveryConfig',JSON.stringify(cfg));
  toast('Configuración guardada');
}
els.saveConfig.addEventListener('click',saveConfig);

async function acquireWakeLock(){
  try{
    if('wakeLock' in navigator){
      wakeLock=await navigator.wakeLock.request('screen');
      wakeLock.addEventListener('release',()=>{});
    }
  }catch(e){}
}
async function releaseWakeLock(){
  try{ if(wakeLock) await wakeLock.release(); }catch(e){}
  wakeLock=null;
}
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='visible' && watchId!==null) acquireWakeLock();
});

async function sendLocation(pos){
  const now=Date.now();
  if(now-lastSent<7000) return;
  lastSent=now;

  const {latitude,longitude,accuracy}=pos.coords;
  els.lat.textContent=latitude.toFixed(6);
  els.lng.textContent=longitude.toFixed(6);
  els.accuracy.textContent=Math.round(accuracy)+' m';
  els.lastUpdate.textContent=new Date().toLocaleTimeString();

  const ajax=els.ajaxUrl.value.trim();
  const token=els.driverToken.value.trim();
  if(!ajax||!token){
    setLive(false,'Falta configurar URL o token');
    return;
  }

  const body=new URLSearchParams({
    action:'fg_update_driver_location',
    token,
    lat:String(latitude),
    lng:String(longitude),
    accuracy:String(accuracy)
  });

  try{
    const r=await fetch(ajax,{
      method:'POST',
      mode:'cors',
      credentials:'omit',
      headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
      body
    });
    const data=await r.json();
    if(data.success){
      setLive(true,'Rastreo activo');
    }else{
      setLive(false,data?.data?.message||'No se pudo actualizar');
    }
  }catch(e){
    setLive(false,'No se pudo conectar con WordPress. Revisa CORS, HTTPS y la URL AJAX.');
  }
}

function geoError(err){
  setLive(false,'Error GPS: '+(err.message||'permiso denegado'));
  els.startBtn.disabled=false; els.stopBtn.disabled=true;
}

els.startBtn.addEventListener('click',async()=>{
  saveConfig();
  if(!navigator.geolocation){
    toast('Este navegador no permite geolocalización');
    return;
  }
  await acquireWakeLock();
  setLive(false,'Solicitando permiso GPS…');
  watchId=navigator.geolocation.watchPosition(
    sendLocation,
    geoError,
    {enableHighAccuracy:true,maximumAge:2000,timeout:15000}
  );
  els.startBtn.disabled=true; els.stopBtn.disabled=false;
});

els.stopBtn.addEventListener('click',async()=>{
  if(watchId!==null) navigator.geolocation.clearWatch(watchId);
  watchId=null;
  await releaseWakeLock();
  els.startBtn.disabled=false; els.stopBtn.disabled=true;
  setLive(false,'Rastreo detenido');
});

els.testConfig.addEventListener('click',async()=>{
  const ajax=els.ajaxUrl.value.trim(), token=els.driverToken.value.trim();
  if(!ajax||!token){toast('Configura URL y token');return;}
  try{
    const body=new URLSearchParams({action:'fg_update_driver_location',token,lat:'14.0818',lng:'-87.2068',accuracy:'9999'});
    const r=await fetch(ajax,{method:'POST',mode:'cors',credentials:'omit',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body});
    const data=await r.json();
    toast(data.success?'Conexión correcta':'Error: '+(data?.data?.message||'sin respuesta'));
  }catch(e){toast('No se pudo conectar');}
});

document.querySelectorAll('.stepper button').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.stepper button').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    toast('Estado local: '+btn.dataset.status);
  });
});

window.addEventListener('beforeinstallprompt',e=>{
  e.preventDefault(); installPrompt=e;
  els.installBtn.classList.remove('hidden');
});
els.installBtn.addEventListener('click',async()=>{
  if(!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt=null;
  els.installBtn.classList.add('hidden');
});

if('serviceWorker' in navigator){
  window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
}

if(urlToken){
  els.orderMeta.textContent='Token del delivery cargado desde el enlace privado.';
}
